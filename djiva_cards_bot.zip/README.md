# Djiva Bot

Telegram-бот «Карты Дживы». Запускается через Railway.

## Команда запуска
```bash
python main.py
```

## Переменные окружения
- `BOT_TOKEN` — токен Telegram-бота